package msa.sonic.view.fiewin3.utils;


import msa.sonic.view.fiewin3.Model.User;

/**
 * Singleton class for managing application configuration settings.
 * This class provides methods to access and modify configuration values such as
 * base URL, authentication tokens, user type, and user data.
 */
public class Config {
    private static Config instance;
    private String baseUrl = "http://10.0.27.198:8080/api";
    private String token;
    private String refreshToken;
    private String userType;
    private User user;

    /**
     * Private constructor to prevent external instantiation.
     */
    private Config() {
        // Constructor privado para evitar instanciación externa
    }

    /**
     * Returns the singleton instance of the Config class.
     * If the instance does not exist, it creates a new one.
     *
     * @return the singleton instance of Config.
     */
    public static synchronized Config getInstance() {
        if (instance == null) {
            instance = new Config();
        }
        return instance;
    }

    /**
     * Gets the base URL for API requests.
     *
     * @return the base URL.
     */
    public String getBaseUrl() {
        return baseUrl;
    }

    /**
     * Sets the base URL for API requests.
     *
     * @param baseUrl the base URL to set.
     */
    public void setBaseUrl(String baseUrl) {
        this.baseUrl = baseUrl;
    }

    /**
     * Gets the authentication token used for API requests.
     *
     * @return the authentication token.
     */
    public String getToken() {
        return token;
    }

    /**
     * Sets the authentication token used for API requests.
     *
     * @param token the authentication token to set.
     */
    public void setToken(String token) {
        this.token = token;
    }

    /**
     * Gets the refresh token used to obtain a new authentication token.
     *
     * @return the refresh token.
     */
    public String getRefreshToken() {
        return refreshToken;
    }

    /**
     * Sets the refresh token used to obtain a new authentication token.
     *
     * @param refreshToken the refresh token to set.
     */
    public void setRefreshToken(String refreshToken) {
        this.refreshToken = refreshToken;
    }

    /**
     * Gets the type of the user (e.g., admin, regular user).
     *
     * @return the user type.
     */
    public String getUserType() {
        return userType;
    }

    /**
     * Sets the type of the user (e.g., admin, regular user).
     *
     * @param userType the user type to set.
     */
    public void setUserType(String userType) {
        this.userType = userType;
    }

    /**
     * Gets the data of the currently logged-in user.
     *
     * @return the user data.
     */
    public User getUserData() {
        return user;
    }

    /**
     * Sets the data of the currently logged-in user.
     *
     * @param user the user data to set.
     */
    public void setUserData(User user) {
        this.user = user;
    }
}
