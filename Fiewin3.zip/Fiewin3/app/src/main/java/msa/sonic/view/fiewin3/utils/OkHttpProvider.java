package msa.sonic.view.fiewin3.utils;

import okhttp3.OkHttpClient;
import okhttp3.logging.HttpLoggingInterceptor;


/**
 * Provides a singleton instance of {@link OkHttpClient} configured with logging.
 * This class ensures that a single instance of {@link OkHttpClient} is used throughout
 * the application, with HTTP logging enabled for debugging purposes.
 */
public class OkHttpProvider {

    private static OkHttpClient okHttpClient;

    /**
     * Returns the singleton instance of {@link OkHttpClient}.
     * If the instance does not exist, it creates and configures a new one.
     *
     * @return the singleton {@link OkHttpClient} instance.
     */
    public static OkHttpClient getClient() {
        if (okHttpClient == null) {
            // Create an HTTP logging interceptor to log request and response data
            HttpLoggingInterceptor logging = new HttpLoggingInterceptor();
            logging.setLevel(HttpLoggingInterceptor.Level.BODY);

            // Build the OkHttpClient with the logging interceptor
            okHttpClient = new OkHttpClient.Builder()
                    .addInterceptor(logging)
                    .build();
        }
        return okHttpClient;
    }
}
