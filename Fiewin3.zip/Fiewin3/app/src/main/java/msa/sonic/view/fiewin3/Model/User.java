package msa.sonic.view.fiewin3.Model;

import java.util.Set;

/**
 * Represents a user with various details.
 */

public class User {
    private String name;
    private String lastname;
    private Set<UserType> usertype;

    /**
     * Constructs a User with the specified details.
     *
     * @param name the name of the user.
     * @param lastname the last name of the user.
     * @param usertype the type of user (e.g., admin, user).
     */
    public User(String name, String lastname, Set<UserType> usertype) {
        this.name = name;
        this.lastname = lastname;
        this.usertype = usertype;
    }

    /**
     * Returns the name of the user.
     *
     * @return the user's name.
     */
    public String getName() {
        return name;
    }

    /**
     * Sets the name of the user.
     *
     * @param name the new name of the user.
     */
    public void setName(String name) {
        this.name = name;
    }

    /**
     * Returns the last name of the user.
     *
     * @return the user's last name.
     */
    public String getLastname() {
        return lastname;
    }

    /**
     * Sets the last name of the user.
     *
     * @param lastname the new last name of the user.
     */
    public void setLastname(String lastname) {
        this.lastname = lastname;
    }

    /**
     * Returns the username of the user.
     *
     * @return the user's username.
     */
    /**
     * Returns the type of user.
     *
     * @return the user's type (e.g., admin, user).
     */
    public Set<UserType> getUsertype() {
        return usertype;
    }

    /**
     * Sets the type of user.
     *
     * @param usertype the new type of user.
     */
    public void setUsertype(Set<UserType> usertype) {
        this.usertype = usertype;
    }

    public enum UserType {
        ROLE_OPERATOR,
        ROLE_ADMIN
    }
}
