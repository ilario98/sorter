package msa.sonic.view.fiewin3.ui.home;

import android.content.Context;
import android.content.SharedPreferences;
import android.os.Bundle;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.TextView;

import androidx.annotation.NonNull;
import androidx.fragment.app.Fragment;
import androidx.lifecycle.ViewModelProvider;

import msa.sonic.view.fiewin3.databinding.FragmentHomeBinding;

public class HomeFragment extends Fragment {

    private FragmentHomeBinding binding;
    private static final String SHARED_PREFS_NAME = "msa.sonic.view.fiewin3.PREFERENCES";
    private static final String USERNAME_KEY = "USERNAME_KEY";

    @Override
    public View onCreateView(@NonNull LayoutInflater inflater,
                             ViewGroup container, Bundle savedInstanceState) {
        HomeViewModel homeViewModel =
                new ViewModelProvider(this).get(HomeViewModel.class);

        binding = FragmentHomeBinding.inflate(inflater, container, false);
        View root = binding.getRoot();

        String formattedName = formatUserName(getUsername());

        TextView userNameTextView = binding.userName;
        userNameTextView.setText(formattedName);

        final TextView textView = binding.textHome;
        homeViewModel.getText().observe(getViewLifecycleOwner(), textView::setText);

        return root;
    }

    @Override
    public void onDestroyView() {
        super.onDestroyView();
        binding = null;
    }

    private String getUsername() {
        SharedPreferences sharedPreferences = getActivity().getSharedPreferences(SHARED_PREFS_NAME, Context.MODE_PRIVATE);
        return sharedPreferences.getString(USERNAME_KEY, "nombre.apellido");
    }

    private String formatUserName(String username) {

        String formattedName = username.replace(".", " ");

        String[] parts = formattedName.split(" ");
        if (parts.length == 2) {
            String firstName = capitalize(parts[0]);
            String lastName = capitalize(parts[1]);
            return firstName + " " + lastName;
        }
        return formattedName;
    }

    private String capitalize(String str) {
        if (str == null || str.isEmpty()) {
            return str;
        }
        return str.substring(0, 1).toUpperCase() + str.substring(1).toLowerCase();
    }
}
