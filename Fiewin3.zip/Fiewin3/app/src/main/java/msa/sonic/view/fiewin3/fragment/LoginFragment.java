package msa.sonic.view.fiewin3.fragment;

import android.content.Context;
import android.content.SharedPreferences;
import android.os.Bundle;
import android.text.TextUtils;
import android.text.method.HideReturnsTransformationMethod;
import android.text.method.PasswordTransformationMethod;
import android.util.Log;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.EditText;
import android.widget.ImageView;
import android.widget.Toast;

import androidx.annotation.NonNull;
import androidx.annotation.Nullable;
import androidx.appcompat.app.AppCompatActivity;
import androidx.fragment.app.Fragment;
import androidx.navigation.NavController;
import androidx.navigation.fragment.NavHostFragment;

import org.json.JSONArray;
import org.json.JSONException;
import org.json.JSONObject;

import java.io.IOException;
import java.util.HashSet;
import java.util.Set;
import java.util.regex.Pattern;

import msa.sonic.view.fiewin3.Model.User;
import msa.sonic.view.fiewin3.R;
import msa.sonic.view.fiewin3.utils.Config;
import msa.sonic.view.fiewin3.utils.OkHttpProvider;
import okhttp3.Call;
import okhttp3.Callback;
import okhttp3.MediaType;
import okhttp3.OkHttpClient;
import okhttp3.Request;
import okhttp3.RequestBody;
import okhttp3.Response;

public class LoginFragment extends Fragment {

    private boolean isPasswordVisible = false;
    private static final Pattern USERNAME_PATTERN = Pattern.compile("^[a-zA-Z0-9._%+-]+\\.[a-zA-Z0-9.-]+$");

    @Nullable
    @Override
    public View onCreateView(@NonNull LayoutInflater inflater, @Nullable ViewGroup container, @Nullable Bundle savedInstanceState) {
        View view = inflater.inflate(R.layout.fragment_login, container, false);

        if (getActivity() != null) {
            ((AppCompatActivity) getActivity()).getSupportActionBar().hide();
        }

        final EditText etUsername = view.findViewById(R.id.etUsername);
        final EditText etPassword = view.findViewById(R.id.etPassword);
        final ImageView togglePasswordVisibility = view.findViewById(R.id.togglePasswordVisibility);

        togglePasswordVisibility.setOnClickListener(v -> {
            if (isPasswordVisible) {
                etPassword.setTransformationMethod(PasswordTransformationMethod.getInstance());
                togglePasswordVisibility.setImageResource(R.drawable.baseline_visibility_24);
            } else {
                etPassword.setTransformationMethod(HideReturnsTransformationMethod.getInstance());
                togglePasswordVisibility.setImageResource(R.drawable.baseline_visibility_off_24);
            }
            isPasswordVisible = !isPasswordVisible;
            etPassword.setSelection(etPassword.getText().length());
        });

        view.findViewById(R.id.btnLogin).setOnClickListener(v -> {
            String username = etUsername.getText().toString();
            String password = etPassword.getText().toString();

            if (validateInput(username, password)) {
                loginUser(username, password, view);
            }
        });

        return view;
    }

    private boolean validateInput(String username, String password) {
        if (TextUtils.isEmpty(username)) {
            Toast.makeText(getActivity(), "El nombre de usuario no puede estar vacío.", Toast.LENGTH_SHORT).show();
            return false;
        }

        if (!USERNAME_PATTERN.matcher(username).matches()) {
            Toast.makeText(getActivity(), "El nombre de usuario debe tener un formato válido: nombre.apellido", Toast.LENGTH_SHORT).show();
            return false;
        }

        if (TextUtils.isEmpty(password)) {
            Toast.makeText(getActivity(), "La contraseña no puede estar vacía.", Toast.LENGTH_SHORT).show();
            return false;
        }
        return true;
    }

    private void loginUser(String username, String password, View view) {
        OkHttpClient client = OkHttpProvider.getClient();
        String baseUrl = Config.getInstance().getBaseUrl();

        MediaType JSON = MediaType.parse("application/json; charset=utf-8");
        JSONObject json = new JSONObject();
        try {
            json.put("username", username);
            json.put("password", password);
        } catch (JSONException e) {
            e.printStackTrace();
        }

        RequestBody body = RequestBody.create(json.toString(), JSON);
        Request request = new Request.Builder()
                .url(baseUrl + "/auth/login")
                .post(body)
                .build();

        client.newCall(request).enqueue(new Callback() {
            @Override
            public void onFailure(Call call, IOException e) {
                getActivity().runOnUiThread(() -> {
                    Toast.makeText(getActivity(), "Error: " + e.getMessage(), Toast.LENGTH_SHORT).show();
                });
            }

            @Override
            public void onResponse(Call call, Response response) throws IOException {
                if (response.isSuccessful()) {
                    String responseBody = response.body().string();
                    Log.d("LoginResponse", responseBody);

                    try {
                        JSONObject jsonResponse = new JSONObject(responseBody);

                        if (jsonResponse.has("token") && jsonResponse.has("refreshToken") && jsonResponse.has("usertype")) {
                            String accessToken = jsonResponse.getString("token");
                            String refreshToken = jsonResponse.getString("refreshToken");
                            JSONArray userTypeArray = jsonResponse.getJSONArray("usertype");

                            Set<User.UserType> userTypeSet = new HashSet<>();
                            for (int i = 0; i < userTypeArray.length(); i++) {
                                String role = userTypeArray.getString(i);
                                if ("ROLE_OPERATOR".equals(role)) {
                                    userTypeSet.add(User.UserType.ROLE_OPERATOR);
                                } else if ("ROLE_ADMIN".equals(role)) {
                                    userTypeSet.add(User.UserType.ROLE_ADMIN);
                                }
                            }

                            SharedPreferences sharedPreferences = getActivity().getSharedPreferences("msa.sonic.view.fiewin3.PREFERENCES", Context.MODE_PRIVATE);
                            SharedPreferences.Editor editor = sharedPreferences.edit();
                            editor.putString("USERNAME_KEY", username);  // Guarda el nombre de usuario completo
                            editor.apply();

                            Config.getInstance().setToken(accessToken);
                            Config.getInstance().setRefreshToken(refreshToken);
                            Config.getInstance().setUserData(new User(jsonResponse.optString("name", ""), jsonResponse.optString("lastname", ""), userTypeSet));

                            getActivity().runOnUiThread(() -> {
                                Toast.makeText(getActivity(), "Inicio de sesión exitoso!", Toast.LENGTH_SHORT).show();
                                navigateToHomeUser(view);
                            });
                        } else {
                            getActivity().runOnUiThread(() -> {
                                Toast.makeText(getActivity(), "Respuesta inesperada del servidor", Toast.LENGTH_SHORT).show();
                            });
                        }
                    } catch (JSONException e) {
                        getActivity().runOnUiThread(() -> {
                            Toast.makeText(getActivity(), "Error parsing response: " + e.getMessage(), Toast.LENGTH_SHORT).show();
                        });
                    }
                } else {
                    String errorMessage = response.body().string();
                    getActivity().runOnUiThread(() -> {
                        Toast.makeText(getActivity(), "Error: " + errorMessage, Toast.LENGTH_SHORT).show();
                    });
                }
            }

        });
    }
    private void navigateToHomeUser(View view) {
        NavController navController = NavHostFragment.findNavController(this);
        navController.navigate(R.id.action_loginFragment_to_navigation_home);
        }
    }

