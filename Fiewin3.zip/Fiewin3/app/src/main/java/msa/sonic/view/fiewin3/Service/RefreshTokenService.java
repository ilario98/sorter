package msa.sonic.view.fiewin3.Service;

import android.content.Context;
import android.content.SharedPreferences;
import android.widget.Toast;

import androidx.appcompat.app.AppCompatActivity;

import org.json.JSONException;
import org.json.JSONObject;

import java.io.IOException;


import msa.sonic.view.fiewin3.utils.Config;
import msa.sonic.view.fiewin3.utils.OkHttpProvider;
import okhttp3.Call;
import okhttp3.Callback;
import okhttp3.MediaType;
import okhttp3.OkHttpClient;
import okhttp3.Request;
import okhttp3.RequestBody;
import okhttp3.Response;

/**
 * Service class for handling token refresh operations.
 * It performs the token refresh process by making a network request to the server and updating stored tokens.
 */
public class RefreshTokenService {

    private static final String SHARED_PREFS_NAME = "msa.sonic.view.fiewin3.PREFERENCES";
    private static final String TOKEN_KEY = "TOKEN_KEY";
    private static final String REFRESH_TOKEN_KEY = "REFRESH_TOKEN_KEY";

    /**
     * Refreshes the authentication token by making a network request to the server.
     * Updates the stored tokens upon successful response.
     *
     * @param context the context used to access shared preferences and display Toast messages.
     */
    public static void refreshToken(Context context) {
        OkHttpClient client = OkHttpProvider.getClient();
        String baseUrl = Config.getInstance().getBaseUrl();

        SharedPreferences sharedPreferences = context.getSharedPreferences(SHARED_PREFS_NAME, Context.MODE_PRIVATE);
        String refreshToken = Config.getInstance().getRefreshToken();
        String token = Config.getInstance().getToken();

        MediaType JSON = MediaType.parse("application/json; charset=utf-8");
        JSONObject json = new JSONObject();
        try {
            json.put("refreshToken", refreshToken);
        } catch (JSONException e) {
            e.printStackTrace();
        }

        RequestBody body = RequestBody.create(json.toString(), JSON);
        Request request = new Request.Builder()
                .url(baseUrl + "auth/refreshtoken")
                .addHeader("Authorization", "Bearer " + token)
                .post(body)
                .build();

        client.newCall(request).enqueue(new Callback() {
            @Override
            public void onFailure(Call call, IOException e) {
                ((AppCompatActivity) context).runOnUiThread(() -> {
                    Toast.makeText(context, "Error al refrescar el token: " + e.getMessage(), Toast.LENGTH_SHORT).show();
                });
            }

            @Override
            public void onResponse(Call call, Response response) throws IOException {
                if (response.isSuccessful()) {
                    String responseBody = response.body().string();
                    try {
                        JSONObject jsonResponse = new JSONObject(responseBody);
                        String newAccessToken = jsonResponse.getString("token");
                        String newRefreshToken = jsonResponse.getString("refreshToken");

                        saveTokens(context, newAccessToken, newRefreshToken);

                        Config.getInstance().setToken(newAccessToken);
                        Config.getInstance().setRefreshToken(newRefreshToken);

                        ((AppCompatActivity) context).runOnUiThread(() -> {
                            Toast.makeText(context, "Token refrescado exitosamente!", Toast.LENGTH_SHORT).show();
                        });
                    } catch (JSONException e) {
                        ((AppCompatActivity) context).runOnUiThread(() -> {
                            Toast.makeText(context, "Error al parsear la respuesta", Toast.LENGTH_SHORT).show();
                        });
                    }
                } else {
                    ((AppCompatActivity) context).runOnUiThread(() -> {
                        Toast.makeText(context, "Error al refrescar el token: " + response.code(), Toast.LENGTH_SHORT).show();
                    });
                }
            }
        });
    }

    /**
     * Saves the new access and refresh tokens to shared preferences.
     *
     * @param context the context used to access shared preferences.
     * @param token the new access token to be saved.
     * @param refreshToken the new refresh token to be saved.
     */
    private static void saveTokens(Context context, String token, String refreshToken) {
        SharedPreferences sharedPreferences = context.getSharedPreferences(SHARED_PREFS_NAME, Context.MODE_PRIVATE);
        SharedPreferences.Editor editor = sharedPreferences.edit();
        editor.putString(TOKEN_KEY, token);
        editor.putString(REFRESH_TOKEN_KEY, refreshToken);
        editor.apply();
    }
}
